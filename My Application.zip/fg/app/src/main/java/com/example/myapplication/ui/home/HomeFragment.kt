package com.example.myapplication.ui.home

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.example.myapplication.R
import kotlinx.android.synthetic.main.fragment_home.view.*
import kotlin.math.round

class HomeFragment : Fragment() {

    private lateinit var homeViewModel: HomeViewModel

    override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        val root = inflater.inflate(R.layout.fragment_home, container, false)
        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        var quantity = view.quantity as EditText
        var quantity_1 = view.quantity3 as EditText
        var quantity_2 = view.quantity4 as EditText
        var quantity_3 = view.quantity5 as EditText
        var quantity_4 = view.quantity6 as EditText
        var inch_1_0 = view.inch1 as EditText
        var inch_1_1 = view.inch4 as EditText
        var inch_1_2 = view.inch6 as EditText
        var inch_1_3 = view.inch8 as EditText
        var inch_1_4 = view.inch10 as EditText
        var inch_2_0 = view.inch2 as EditText
        var inch_2_1 = view.inch5 as EditText
        var inch_2_2 = view.inch7 as EditText
        var inch_2_3 = view.inch9 as EditText
        var inch_2_4 = view.inch11 as EditText
        var inchsq_0 = view.inchsq as EditText
        var inchsq_1 = view.inchsq2 as EditText
        var inchsq_2 = view.inchsq3 as EditText
        var inchsq_3 = view.inchsq4 as EditText
        var inchsq_4 = view.inchsq5 as EditText
        var costprt_0 = view.Costprt as EditText
        var costprt_1 = view.costprt2 as EditText
        var costprt_2 = view.costprt3 as EditText
        var costprt_3 = view.costprt4 as EditText
        var costprt_4 = view.costprt5 as EditText
        var cost_0 = view.cost as EditText
        var cost_1 = view.cost2 as EditText
        var cost_2 = view.cost3 as EditText
        var cost_3 = view.cost4 as EditText
        var cost_4 = view.cost5 as EditText
        var quantity_array = arrayOf(quantity,quantity_1,quantity_2,quantity_3,quantity_4)
        var inch_1_array = arrayOf(inch_1_0,inch_1_1,inch_1_2,inch_1_3,inch_1_4)
        var inch_2_array = arrayOf(inch_2_0,inch_2_1,inch_2_2,inch_2_3,inch_2_4)
        var inchsq_array = arrayOf(inchsq_0,inchsq_1,inchsq_2,inchsq_3,inchsq_4)
        var costprt_array = arrayOf(costprt_0,costprt_1,costprt_2,costprt_3,costprt_4)
        var cost_array = arrayOf(cost_0,cost_1,cost_2,cost_3,cost_4)
        var calculate = view.calc as Button
        calculate.setOnClickListener {
                Toast.makeText(activity, "ffff", Toast.LENGTH_SHORT).show()
            var quantity_val :Int? = quantity.text.toString().toIntOrNull()
            println("${quantity_val} is a string")
            check(quantity_array,inch_1_array,inch_2_array,inchsq_array,costprt_array,cost_array)
        }

    }
    fun check(a: Array<EditText>, b: Array<EditText>, c:Array<EditText>,d:Array<EditText>,e:Array<EditText>, f:Array<EditText>)
    {
        for (i in 0..a.size-1)
        {
            if(a[i].text.toString().toDoubleOrNull() != null && b[i].text.toString().toDoubleOrNull() != null && c[i].text.toString().toDoubleOrNull() !=null)
            {
                var quantity = a[i].text.toString().toDouble()
                var inch_1 = b[i].text.toString().toDouble()
                var inch_2 = c[i].text.toString().toDouble()
                var sqft = round(inch_1*inch_2*100.0)/100
                var cost = round(((sqft * 10)+0.05*(sqft*10)*quantity)*100.0)/ 100
                var print = round(sqft * 3.5 * quantity * 100.0)/100
                d[i].setText(sqft.toString())
                e[i].setText(cost.toString())
                f[i].setText(print.toString())

                println("they are not null")
            }
        }
    }
}

